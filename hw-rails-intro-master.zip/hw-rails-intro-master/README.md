# RottenPotatoes demo app: getting started

This app is associated with the [online
course](http://www.saas-class.org) and free
[textbook](http://www.saasbook.info) Engineering Software as a Service.

This repo contains starter code related to specific assignments.
Please go to the specific assignment for instructions.  
If you're taking this course on edX or if your classroom is using
Codio, the assignments are linked from there.  Alternatively, you can
follow links to the assignment GitHub repos from the textbook.

